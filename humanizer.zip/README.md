# Humanize: AI script humanizer

Next.js 15 + Tailwind 4 + SQLite. Paste an AI script, pick an emotion (Funny, Inspiring, Threatening...), get a human rewrite. Email/password auth, history with search/filter, Stripe Pro tier (3 free rewrites).

## Run locally
1. `npm install`
2. `cp .env.example .env` and fill in values (below)
3. `npm run dev` then open http://localhost:3000

## Environment variables
| Var | Purpose |
|---|---|
| AUTH_SECRET | Long random string (`openssl rand -hex 32`) |
| ANTHROPIC_API_KEY | From console.anthropic.com |
| ANTHROPIC_MODEL | Optional model override |
| FREE_LIMIT | Free rewrites per user (default 3) |
| APP_URL | Public URL, no trailing slash |
| STRIPE_SECRET_KEY | Test key `sk_test_...` |
| STRIPE_PRICE_ID | Recurring price created in Stripe dashboard |
| STRIPE_WEBHOOK_SECRET | From `stripe listen` locally, or the dashboard endpoint |

## Stripe test mode
1. Create a product with a recurring monthly price; put its ID in STRIPE_PRICE_ID.
2. Locally: `stripe listen --forward-to localhost:3000/api/webhook`, copy the `whsec_` into .env.
3. Pay with card 4242 4242 4242 4242.

## Deploy
SQLite needs a persistent disk, so **don't use Vercel as-is** (its filesystem is ephemeral). Use Railway, Fly.io or Render with a volume:
- Build `npm run build`, start `npm start`.
- Mount a volume and set `DB_PATH=/data/data.db`.
- Set all env vars; set APP_URL to your domain.
- In Stripe, add webhook endpoint `https://YOURDOMAIN/api/webhook` for `checkout.session.completed` and `customer.subscription.deleted`.
To use Vercel, swap `lib/db.js` for Turso or Postgres.
