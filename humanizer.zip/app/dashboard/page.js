import { redirect } from "next/navigation";
import { getUser } from "@/lib/auth";
import Workspace from "./Workspace";
export default async function Dashboard() {
  const u = await getUser(); if (!u) redirect("/login");
  return <Workspace email={u.email} pro={u.plan === "pro"} left={Math.max(0, Number(process.env.FREE_LIMIT || 3) - u.used)} />;
}
