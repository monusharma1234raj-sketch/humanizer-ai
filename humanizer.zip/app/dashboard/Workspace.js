"use client";
import { useEffect, useState } from "react";
import { TONES } from "@/lib/ai";
export default function Workspace({ email, pro, left: l0 }) {
  const [text, setText] = useState(""), [tone, setTone] = useState("Natural"), [out, setOut] = useState(null);
  const [busy, setBusy] = useState(false), [err, setErr] = useState(""), [left, setLeft] = useState(l0);
  const [hist, setHist] = useState([]), [q, setQ] = useState(""), [ft, setFt] = useState("");
  const load = () => fetch(`/api/scripts?q=${encodeURIComponent(q)}&tone=${ft}`).then((r) => r.json()).then(setHist);
  useEffect(() => { load(); }, [q, ft]);
  async function go() {
    setBusy(true); setErr("");
    const r = await fetch("/api/rewrite", { method: "POST", body: JSON.stringify({ text, tone }) });
    const d = await r.json(); setBusy(false);
    if (!r.ok) return setErr(d.error === "limit" ? "Free limit reached. Upgrade to keep going." : d.error);
    setOut(d); setLeft((n) => n - 1); load();
  }
  async function upgrade() { const r = await fetch("/api/checkout", { method: "POST" }); location.href = (await r.json()).url; }
  async function logout() { await fetch("/api/auth", { method: "POST", body: JSON.stringify({ mode: "logout" }) }); location.href = "/"; }
  async function del(id) { await fetch(`/api/scripts?id=${id}`, { method: "DELETE" }); load(); }
  const chip = (on) => `rounded-full border px-3 py-1 text-sm ${on ? "border-blue-600 bg-blue-600 text-white" : "bg-white hover:border-blue-400"}`;
  return (<main className="mx-auto max-w-5xl p-5">
    <header className="mb-6 flex flex-wrap items-center justify-between gap-3">
      <b className="text-xl text-blue-600">Humanize</b>
      <div className="flex items-center gap-3 text-sm"><span className="text-slate-500">{email}</span>
        {pro ? <span className="rounded bg-blue-100 px-2 py-1 font-medium text-blue-700">Pro</span> : <button onClick={upgrade} className="rounded-lg bg-blue-600 px-3 py-1.5 font-medium text-white hover:bg-blue-700">Upgrade ({left} free left)</button>}
        <button onClick={logout} className="text-slate-500 hover:text-blue-600">Log out</button></div>
    </header>
    <section className="rounded-2xl border bg-white p-5">
      <textarea value={text} onChange={(e) => setText(e.target.value)} rows={8} placeholder="Paste your AI-generated script here..." className="w-full resize-y rounded-lg border p-3 outline-none focus:ring-2 focus:ring-blue-500" />
      <div className="mt-3 flex flex-wrap gap-2">{TONES.map((t) => <button key={t} onClick={() => setTone(t)} className={chip(tone === t)}>{t}</button>)}</div>
      <div className="mt-4 flex items-center gap-3"><button onClick={go} disabled={busy || text.length < 20} className="rounded-lg bg-blue-600 px-5 py-2 font-semibold text-white hover:bg-blue-700 disabled:opacity-50">{busy ? "Rewriting..." : `Humanize (${tone})`}</button><span className="text-sm text-red-600">{err}</span></div>
      {out && <div className="mt-5 rounded-lg bg-blue-50 p-4"><p className="whitespace-pre-wrap">{out.output}</p><button onClick={() => navigator.clipboard.writeText(out.output)} className="mt-3 text-sm font-medium text-blue-700">Copy</button></div>}
    </section>
    <section className="mt-8">
      <div className="mb-3 flex flex-wrap items-center gap-3"><h2 className="font-semibold">History</h2>
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search..." className="rounded-lg border px-3 py-1.5 text-sm" />
        <select value={ft} onChange={(e) => setFt(e.target.value)} className="rounded-lg border px-2 py-1.5 text-sm"><option value="">All tones</option>{TONES.map((t) => <option key={t}>{t}</option>)}</select></div>
      {hist.length === 0 ? <p className="rounded-2xl border border-dashed p-10 text-center text-slate-500">No rewrites yet. Paste a script above to get started.</p> :
        <ul className="space-y-3">{hist.map((h) => <li key={h.id} className="rounded-xl border bg-white p-4"><div className="mb-1 flex justify-between text-xs text-slate-500"><span className="rounded bg-blue-100 px-2 py-0.5 text-blue-700">{h.tone}</span><span>{h.created}<button onClick={() => del(h.id)} className="ml-3 hover:text-red-600">Delete</button></span></div>
          <p className="line-clamp-3 text-sm">{h.output}</p><button onClick={() => { setOut(h); scrollTo(0, 0); }} className="mt-2 text-sm text-blue-600">Open</button></li>)}</ul>}
    </section></main>);
}
