"use client";
import { useState } from "react";
export default function Login() {
  const [mode, setMode] = useState(typeof window !== "undefined" && location.search.includes("signup") ? "signup" : "login");
  const [err, setErr] = useState(""); const [busy, setBusy] = useState(false);
  async function submit(e) {
    e.preventDefault(); setBusy(true); setErr("");
    const f = new FormData(e.target);
    const r = await fetch("/api/auth", { method: "POST", body: JSON.stringify({ mode, email: f.get("email"), password: f.get("password") }) });
    if (r.ok) location.href = "/dashboard"; else { setErr((await r.json()).error); setBusy(false); }
  }
  const inp = "w-full rounded-lg border px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500";
  return (<main className="flex min-h-screen items-center justify-center p-5">
    <form onSubmit={submit} className="w-full max-w-sm space-y-4 rounded-2xl border bg-white p-7 shadow-sm">
      <h1 className="text-2xl font-bold text-blue-600">{mode === "signup" ? "Create account" : "Welcome back"}</h1>
      <input name="email" type="email" placeholder="Email" required className={inp} />
      <input name="password" type="password" placeholder="Password (8+ chars)" required className={inp} />
      {err && <p className="text-sm text-red-600">{err}</p>}
      <button disabled={busy} className="w-full rounded-lg bg-blue-600 py-2 font-semibold text-white hover:bg-blue-700 disabled:opacity-50">{mode === "signup" ? "Sign up" : "Sign in"}</button>
      <button type="button" onClick={() => setMode(mode === "signup" ? "login" : "signup")} className="w-full text-sm text-slate-500 hover:text-blue-600">{mode === "signup" ? "Have an account? Sign in" : "New here? Create account"}</button>
    </form></main>);
}
