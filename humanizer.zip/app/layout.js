import "./globals.css";
export const metadata = { title: "Humanize — make AI scripts sound like you", description: "Paste an AI script. Get a human version in any emotion." };
export default function RootLayout({ children }) {
  return <html lang="en"><body className="bg-slate-50 text-slate-900 antialiased">{children}</body></html>;
}
