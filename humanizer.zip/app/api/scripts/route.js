import db from "@/lib/db";
import { getUser } from "@/lib/auth";
export async function GET(req) {
  const u = await getUser(); if (!u) return Response.json([], { status: 401 });
  const p = new URL(req.url).searchParams, q = `%${p.get("q") || ""}%`, tone = p.get("tone") || "";
  return Response.json(db.prepare("select * from scripts where user_id=? and (input like ? or output like ?) and (?='' or tone=?) order by id desc limit 100").all(u.id, q, q, tone, tone));
}
export async function DELETE(req) {
  const u = await getUser(); if (!u) return Response.json({}, { status: 401 });
  db.prepare("delete from scripts where id=? and user_id=?").run(new URL(req.url).searchParams.get("id"), u.id);
  return Response.json({ ok: true });
}
