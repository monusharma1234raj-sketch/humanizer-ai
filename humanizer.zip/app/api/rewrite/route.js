import db from "@/lib/db";
import { getUser } from "@/lib/auth";
import { humanize, TONES } from "@/lib/ai";
export async function POST(req) {
  const u = await getUser();
  if (!u) return Response.json({ error: "Not signed in" }, { status: 401 });
  const limit = Number(process.env.FREE_LIMIT || 3);
  if (u.plan !== "pro" && u.used >= limit) return Response.json({ error: "limit" }, { status: 402 });
  const { text = "", tone = "Natural" } = await req.json();
  if (text.trim().length < 20 || text.length > 12000 || !TONES.includes(tone)) return Response.json({ error: "Paste 20 to 12,000 characters" }, { status: 400 });
  try {
    const output = await humanize(text, tone);
    const id = db.prepare("insert into scripts(user_id,tone,input,output) values(?,?,?,?)").run(u.id, tone, text, output).lastInsertRowid;
    db.prepare("update users set used=used+1 where id=?").run(u.id);
    return Response.json(db.prepare("select * from scripts where id=?").get(id));
  } catch (err) { return Response.json({ error: err.message }, { status: 500 }); }
}
