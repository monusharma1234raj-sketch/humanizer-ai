import bcrypt from "bcryptjs";
import db from "@/lib/db";
import { setSession, clearSession } from "@/lib/auth";
export async function POST(req) {
  const { mode, email = "", password = "" } = await req.json();
  if (mode === "logout") { await clearSession(); return Response.json({ ok: true }); }
  const e = email.trim().toLowerCase();
  if (!/^\S+@\S+\.\S+$/.test(e) || password.length < 8) return Response.json({ error: "Valid email and 8+ character password required" }, { status: 400 });
  let u = db.prepare("select * from users where email=?").get(e);
  if (mode === "signup") {
    if (u) return Response.json({ error: "Email already registered" }, { status: 400 });
    const id = db.prepare("insert into users(email,hash) values(?,?)").run(e, bcrypt.hashSync(password, 10)).lastInsertRowid;
    await setSession(Number(id));
  } else {
    if (!u || !bcrypt.compareSync(password, u.hash)) return Response.json({ error: "Wrong email or password" }, { status: 401 });
    await setSession(u.id);
  }
  return Response.json({ ok: true });
}
