import Link from "next/link";
const F = [["Sounds human", "Strips AI cliches and robotic rhythm so your script reads like you talking."], ["Pick an emotion", "Funny, inspiring, threatening, dramatic and more, in one click."], ["Keep every draft", "Searchable history of all your rewrites, ready to copy."]];
export default function Home() {
  return (<main>
    <nav className="mx-auto flex max-w-5xl items-center justify-between p-5"><b className="text-xl text-blue-600">Humanize</b><Link href="/login" className="text-sm font-medium hover:text-blue-600">Sign in</Link></nav>
    <section className="mx-auto max-w-3xl px-5 py-20 text-center">
      <h1 className="text-4xl font-bold tracking-tight sm:text-6xl">Make your AI script <span className="text-blue-600">sound human</span></h1>
      <p className="mt-6 text-lg text-slate-600">Paste your AI-generated script, pick a vibe, and get a version your audience will believe you wrote.</p>
      <Link href="/login?mode=signup" className="mt-8 inline-block rounded-xl bg-blue-600 px-7 py-3 font-semibold text-white shadow hover:bg-blue-700">Try it free</Link>
    </section>
    <section className="mx-auto grid max-w-5xl gap-5 px-5 sm:grid-cols-3">{F.map(([t, d]) => <div key={t} className="rounded-2xl border bg-white p-6"><h3 className="font-semibold text-blue-700">{t}</h3><p className="mt-2 text-sm text-slate-600">{d}</p></div>)}</section>
    <section className="mx-auto my-20 grid max-w-3xl gap-5 px-5 sm:grid-cols-2">
      <div className="rounded-2xl border bg-white p-6"><h3 className="font-semibold">Free</h3><p className="my-2 text-3xl font-bold">$0</p><p className="text-sm text-slate-600">3 rewrites, all emotions</p></div>
      <div className="rounded-2xl border-2 border-blue-600 bg-white p-6"><h3 className="font-semibold text-blue-700">Pro</h3><p className="my-2 text-3xl font-bold">$12<span className="text-base font-normal">/mo</span></p><p className="text-sm text-slate-600">Unlimited rewrites + full history</p></div>
    </section>
  </main>);
}
